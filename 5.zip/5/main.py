


def draw_line(vent, sea_floor_map):
  print(vent)
  moving_direction = 1 if (vent[0][0] == vent[1][0]) else 0 # 1 indicates vertical movement, 0 indicates horizontal

  vent_start = min(vent[0][moving_direction], vent[1][moving_direction])
  vent_end = max(vent[0][moving_direction], vent[1][moving_direction]) + 1
  fixed_orientation = vent[0][1 if moving_direction == 0 else 0]

  movement = range(vent_start, vent_end)

  # Move vertically
  if vent[0][0] == vent[1][0]:
    for y_movement in movement:
      sea_floor_map[y_movement][fixed_orientation] += 1
  # Move horizontally
  elif vent[0][1] == vent[1][1]:
    for x_movement in movement:
      sea_floor_map[fixed_orientation][x_movement] += 1

def create_sea_map(input):
  # Get the highest X and Y value. Then we can populate an empty map
  highest_x = 0
  highest_y = 0
  for line in input:
    for coord in line:
      if coord[0] > highest_x:
        highest_x = coord[0]
      if coord[1] > highest_y:
        highest_y = coord[1]

  x_map_list = [0] * (highest_x + 1)
  # We now have a fully featured map
  sea_floor_map = [x_map_list] * (highest_y + 1)

  return sea_floor_map

def calculate_hits(sea_floor_map, vents):
  for vent in vents:
    draw_line(vent, sea_floor_map)
  return sea_floor_map

def main():
  with open('./input_test.txt') as f:
    content = f.readlines()
  content = [x.strip() for x in content]
  
  # Turn input into list of lists with path of vents
  vents = []
  for line in content:
    new_line = []
    vent_coords = line.split(' -> ')
    for coord in vent_coords:
      new_line.append([int(item) for item in coord.split(',')])
    # REMOVE DIAGONALS FROM CODE
    # WDHUIAWDHIU
    if (new_line[0][0] == new_line[1][0]) or (new_line[0][1] == new_line[1][1]):
      vents.append(new_line)

  print(vents)
  sea_floor_map = create_sea_map(vents)
  final_sea_floor_map = calculate_hits(sea_floor_map, vents)
    
  print(final_sea_floor_map)
  for row in final_sea_floor_map:
    print(row)

if __name__ == '__main__':
  main()